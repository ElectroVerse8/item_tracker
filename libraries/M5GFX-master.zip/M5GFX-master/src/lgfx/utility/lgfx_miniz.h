#define LGFX_MINIZ_HEADER_FILE_ONLY
#include "lgfx_miniz.c"
